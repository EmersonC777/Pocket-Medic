(function () {
    'use strict';

    angular.module('app.ambiental', [
        'app.ambiental.directivas',
        'app.ambiental.router'
    ]);

})();
