(function(){
  'use strict';

    angular.module('app.perfil',[
      'app.perfil.directive',
      'app.perfil.route',
      'app.perfil.controller'
    ]);
})();
