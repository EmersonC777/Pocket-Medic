(function () {
  'use strict';

  angular.module('app.perfil.controller',[
  ]).controller('perfilCtrl', perfilCtrl);

  perfilCtrl.$inject = ['$stateParams','$location', '$mdToast','Usuarios'];
    function perfilCtrl($stateParams, $location, $mdToast, Usuarios){

           this.usuario = Usuarios.get({ idUsuario: $stateParams.idUsuario });
           console.log(this.usuario);

          //  vm.update = function() {
          //      Usuarios.update(this.usuario, function() {
          //          $location.path('/');
          //          $mdToast.show(
          //              $mdToast.simple()
          //              .textContent('Se ha  actualizado el  Usuario...')
          //              .position('bottom right'));
          //      });
          //  }
      }

})();
