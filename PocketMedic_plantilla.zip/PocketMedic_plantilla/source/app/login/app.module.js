(function(){
  'use strict';

  angular.module('app.login',[
    'app.login.directive',
    'app.login.router',
    'app.login.controller'

  ]);

})();
