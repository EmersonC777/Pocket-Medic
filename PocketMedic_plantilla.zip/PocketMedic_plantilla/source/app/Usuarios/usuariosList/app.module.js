(function () {
    'use strict';

    angular.module('app.usuariosList', [
        'app.usuariosList.services',
        'app.usuariosList.route',
        'app.usuariosList.controller',
        'app.usuariosList.directivas'
    ]);

})();
