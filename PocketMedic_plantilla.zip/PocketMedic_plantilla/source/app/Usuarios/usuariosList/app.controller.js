(function(){
  'use strict';

  angular.module('app.usuariosList.controller', [
  ]).controller('usuariosListCtrl', usuariosListCtrl);

  usuariosListCtrl.$inject = ['$location', '$mdToast', 'Usuarios'];
    function usuariosListCtrl($location, $mdToast, Usuarios) {

        var vm = this;
         vm.usuarios = Usuarios.query();
    }
})();
