(function(){
  'use strict';

  angular.module('app.usuariosList.services',[

  ])
  .factory('Usuarios', Usuarios)

    ListaUsuarios.$inject=['$resource','BASEURL'];
    function Usuarios($resource, BASEURL) {
        return $resource(BASEURL + 'listausuarios/')

    }

})();
