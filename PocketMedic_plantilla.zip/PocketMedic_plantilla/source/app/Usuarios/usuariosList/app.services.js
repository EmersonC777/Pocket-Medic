(function(){
  'use strict';

  angular.module('app.usuariosList.services',[

  ])
  .factory('ListaUsuarios', ListaUsuarios)

    ListaUsuarios.$inject=['$resource','BASEURL'];
    function ListaUsuarios($resource, BASEURL) {
        return $resource(BASEURL + 'listausuarios/')

    }

})();
