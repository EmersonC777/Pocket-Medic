(function(){
  'use strict';

    angular.module('app.Usuarios',[
      'app.usuariosList'
    ]);
})();
