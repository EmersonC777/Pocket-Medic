(function () {
    'use strict';

    angular.module('app.admin', [
        'app.admin.controller',
        'app.admin.services',
        'app.admin.router',
        'app.admin.directivas',
    ]);

})();