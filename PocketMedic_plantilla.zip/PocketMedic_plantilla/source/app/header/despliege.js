function desplegable(){
  $('#').slideToggle();
  return false;
}

function desplegable1(){
  $('#Vision').slideToggle();
  return false;
}

function desplegable2(){
  $('#Valores').slideToggle();
  return false;
}
