(function (){
  'use strict';

   angular.module('app.header',[
          'app.header.directive'
   ]);
})();
