(function(){
  'use strcit';

  angular.module('app.registro.services',[

  ]).factory('Usuarios', Usuarios)
    .factory('Roles', Roles)
    .factory('Ciudades', Ciudades);

    Usuarios.$inject=['$resource','BASEURL'];
    function Usuarios($resource, BASEURL) {
        return $resource(BASEURL + 'usuarios/:idUsuario',
        { idUsuario: '@idUsuario' },
        { 'get':    {method:'GET'},
          'save':   {method:'POST'},
          'query':  {method:'GET', isArray:true},
          'delete': {method:'DELETE'},
          'update': {method: 'PUT'}
        })
    }

    Roles.$inject = ['$resource', 'BASEURL'];
    function Roles($resource, BASEURL) {
        return $resource(BASEURL + 'roles/:idRol',
        { idRol: '@idRol' },
        { 'get':    {method:'GET'},
          'save':   {method:'POST'},
          'query':  {method:'GET', isArray:true},
          'delete': {method:'DELETE'},
          'update': {method: 'PUT'}
        })
    }

    function Ciudades($resource, BASEURL) {
        return $resource(BASEURL + 'ciudades/:idCiudad', {
            idCiudad: '@idCiudad'
        },{
          queryByNombre: {
            url: BASEURL + 'ciudades/nombre/:query',
            method: 'GET',
            isArray: true,
            params: {
              query: '@query'
            }
          }
        });
    }

})();
