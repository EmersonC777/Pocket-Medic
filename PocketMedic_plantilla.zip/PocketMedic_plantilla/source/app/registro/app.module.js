(function () {
    'use strict';

    angular.module('app.registro', [
        'app.registro.directivas',
        'app.registro.route',
        'app.registro.controller',
        'app.registro.services'
    ]);

})();
