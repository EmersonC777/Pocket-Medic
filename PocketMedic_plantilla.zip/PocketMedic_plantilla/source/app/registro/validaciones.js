$( document ).ready(function() {
        $('#FormRegistro').submit(function(e) {
            e.preventDefault();
        }).validate({
            debug: false,
            rules: {"rol": {required: true},
                "nombre": {required: true},
                "apellido": {required: true},
                "telefono": {required: true},
                "direccion": {required: true},
                "ciudad": {required: true},
                "tarjeta": {required: true},
                "fecha": {required: true},
                "sexo": {required: true},
                "email": {required: true},
                "password":{required:true}},
            messages: {"rol": {required: "Escoga un Rol"},
              "nombre": {required: "Introduce Tu Nombre"},
              "apellido": {required: "Introduce Tu Apellido"},
              "telefono": {required: "Introduce Tu Telefono"},
              "direccion": {required: "Introduce Tu Direccion"},
              "ciudad": {required: "Introduce Tu Ciudad"},
              "tarjeta": {required: "Introduce Tu Tarjeta"},
              "fecha": {required: "Introduce Tu Fecha De Nacimiento"},
              "sexo": {required: "Escoge Tu Sexo"},
              "email": {required: "Introduce Tu Email"},
              "password":{required: "Introduce Tu Contraseña"}
          }

    });
});
