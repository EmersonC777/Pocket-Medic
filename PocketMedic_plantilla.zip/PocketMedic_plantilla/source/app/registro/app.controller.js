(function(){
  'use strict';

  angular.module('app.registro.controller', [

  ]).controller('usuariosCreateCtrl', usuariosCreateCtrl);

  usuariosCreateCtrl.$inject = ['$location', '$mdToast', 'Usuarios', 'Ciudades', 'Roles'];
    function usuariosCreateCtrl($location, $mdToast, Usuarios, Ciudades, Roles) {
        
        /*this.ciudades = Ciudades.query();*/
        this.SelectRol;
        this.queryCiudades = queryCiudades;
        this.roles=Roles.query();
      //  console.log(this.queryRoles.length);
        this.dateMax = new Date();
        this.dateMax.setFullYear(this.dateMax.getFullYear() - 18);

        this.create = function() {
            Usuarios.save(this.usuario, function() {
                $location.path('/');
                $mdToast.show(
                    $mdToast.simple()
                        .textContent('Te has Registrado Exitosamente')
                        .position('bottom right'));
            }, function(error) {
                $mdToast.show(
                    $mdToast.simple()
                    .textContent(error.status + ' ' + error.data)
                    .position('bottom right'));
            });
        }

        function queryCiudades(str){
          return Ciudades.queryByNombre({
            query: str
          });
        }

        getRoles.$inject = ['Roles'];
        function getRoles(Roles) {
        return Roles.query();
        }


    }


})();
