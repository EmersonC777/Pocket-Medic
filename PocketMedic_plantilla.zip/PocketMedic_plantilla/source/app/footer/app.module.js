(function () {
    'use strict';

    angular.module('app.footer', [
        'app.footer.directivas',
    ]);

})();