(function(){
    'use strict';

    angular.module('app.usuarios', [
            'app.usuarios.directive',
            'app.usuarios.router'
    ]);
})();
