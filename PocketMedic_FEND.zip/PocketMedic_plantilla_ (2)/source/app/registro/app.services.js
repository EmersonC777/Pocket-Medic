(function(){
  'use strcit';

  angular.module('app.registro.services',[

  ]).factory('Usuarios', Usuarios)
    .factory('Ciudades', Ciudades);

    Usuarios.$inject=['$resource','BASEURL'];
    function Usuarios($resource, BASEURL) {
        return $resource(BASEURL + 'usuarios/:idUsuario',
        { idUsuario: '@idUsuario' },
        { 'get':    {method:'GET'},
          'save':   {method:'POST'},
          'query':  {method:'GET', isArray:true},
          'delete': {method:'DELETE'},
          'update': {method: 'PUT'}
        })
    }

    Ciudades.$inject = ['$resource', 'BASEURL'];
    function Ciudades($resource, BASEURL) {
        return $resource(BASEURL + 'ciudades/:idCiudad',
        { idCiudad: '@idCiudad' },
        { 'get':    {method:'GET'},

          'query':  {method:'GET', isArray:true}

        })
    }

})();
