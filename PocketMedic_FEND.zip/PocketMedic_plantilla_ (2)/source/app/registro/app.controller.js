(function(){
  'use strict';

  angular.module('app.registro.controller', [

  ]).controller('usuariosCreateCtrl', usuariosCreateCtrl);

  usuariosCreateCtrl.$inject = ['$location', '$mdToast', 'Usuarios', 'Ciudades'];
    function usuariosCreateCtrl($location, $mdToast, Usuarios, Ciudades) {
        this.ciudades = Ciudades.query();
        this.create = function() {
            Usuarios.save(this.usuario, function() {
                $location.path('/');
                $mdToast.show(
                    $mdToast.simple()
                        .textContent('Te has Registrado Exitosamente')
                        .position('bottom right'));
            });
        }
    }

  function queryCiudades(str){
    return Ciudades.queryByNombre({
      query: str
    });
  }

getCiudades.$inject=['Ciudades'];
function getCiudades(Ciudades){
    return Ciudades.query();
}

getCiudades.$inject=['Roles'];
function getRoles(Roles){
    return Roles.query();
}

})();
