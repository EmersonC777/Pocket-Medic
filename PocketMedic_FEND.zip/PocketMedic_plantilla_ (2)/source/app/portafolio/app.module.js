(function () {
    'use strict';

    angular.module('app.portafolio', [
        'app.portafolio.directivas',
        'app.portafolio.router'
    ]);


})();
