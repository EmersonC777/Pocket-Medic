(function(){
  'use strict';

  angular.module('app.registro.controller', [

  ]).controller('usuariosCreateCtrl', usuariosCreateCtrl);

  usuariosCreateCtrl.$inject = ['$location', '$mdToast', 'Usuarios', 'Ciudades'];
    function usuariosCreateCtrl($location, $mdToast, Usuarios, Ciudades) {
        this.ciudades = Ciudades.query();
        this.create = function() {
            Usuarios.save(this.categoria, function() {
                $location.path('/');
                $mdToast.show(
                    $mdToast.simple()
                        .textContent('Te has Registrado Exitosamente')
                        .position('bottom right'));
            });
        }
    }


})();
