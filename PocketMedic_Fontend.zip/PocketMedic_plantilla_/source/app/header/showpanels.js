
 var $panel = $('#PanelLogin'),
     $MainMenuPrimary = $('#MainMenuPrimary'),
     $MainMenuSecundary = $('#MainMenuSecundary');

 function showLogin(){
   $('#PanelLogin').slideToggle();
   return false;
 }

 function showMainMenuPrimary(){
   $('#MainMenuPrimary').slideToggle();
   return false;
 }


 function MainMenuSecundary(){
   $('#MainMenuSecundary').slideToggle();
   return false;
 }
