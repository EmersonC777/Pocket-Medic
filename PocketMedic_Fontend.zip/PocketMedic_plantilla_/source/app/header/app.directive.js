(function(){
  'use strict';

  angular.module('app.header.directive', [

  ]).directive('encabezado', encabezado)
  .directive('encabezadosimple', encabezadosimple);

  function encabezado(){
    return {
      scope:{},
      templateUrl: 'app/header/header.html'
  };
}

  function encabezadosimple(){
    return {
      scope:{},
      templateUrl: 'app/header/headeronlynav.html'
  };
}





})();
