(function () {
    'use strict';

    angular.module('app.ambiental.directivas', [

    ]).directive('ambiental', ambiental);

    function ambiental() {
        return {
            scope: {},
            templateUrl: 'app/ambiental/ambiental.html'
        }
    }
})();
